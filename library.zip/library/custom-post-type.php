<?php
/* Bones Custom Post Type Example
This page walks you through creating 
a custom post type and taxonomies. You
can edit this one or copy the following code 
to create another one. 

I put this in a seperate file so as to 
keep it organized. I find it easier to edit
and change things if they are concentrated
in their own file.

Developed by: Eddie Machado
URL: http://themble.com/bones/
*/


// let's create the function for the custom type
function custom_program() { 
	// creating (registering) the custom type 
	register_post_type( 'program', /* (http://codex.wordpress.org/Function_Reference/register_post_type) */
	 	// let's now add all the options for this post type
		array('labels' => array(
			'name' => __('Programs', 'program general name'), /* This is the Title of the Group */
			'singular_name' => __('Program', 'program singular name'), /* This is the individual type */
			'add_new' => __('Add New', 'program type item'), /* The add new menu item */
			'add_new_item' => __('Add New Program'), /* Add New Display Title */
			'edit' => __( 'Edit' ), /* Edit Dialog */
			'edit_item' => __('Edit Programs'), /* Edit Display Title */
			'new_item' => __('New Program'), /* New Display Title */
			'view_item' => __('View Program'), /* View Display Title */
			'search_items' => __('Search Programs'), /* Search Custom Type Title */ 
			'not_found' =>  __('Nothing found in the Database.'), /* This displays if there are no entries yet */ 
			'not_found_in_trash' => __('Nothing found in Trash'), /* This displays if there is nothing in the trash */
			'parent_item_colon' => ''
			), /* end of arrays */
			'description' => __( 'This is the custom post type for handling all programs administered by the TEDCenter' ), /* Custom Type Description */
			'public' => true,
			'publicly_queryable' => true,
			'exclude_from_search' => false,
			'show_ui' => true,
			'query_var' => true,
			'menu_position' => 8, /* this is what order you want it to appear in on the left hand side menu */ 
			'menu_icon' => get_stylesheet_directory_uri() . '/library/images/custom-post-icon.png', /* the icon for the custom post type menu */
			'rewrite' => true,
			'capability_type' => 'post',
			'hierarchical' => false,
			/* the next one is important, it tells what's enabled in the post editor */
			'supports' => array( 'title', 'editor', 'excerpt')
	 	) /* end of options */
	); /* end of register post type */
	
	/* this ads your post categories to your custom post type */
	register_taxonomy_for_object_type('category', 'program');
	/* this ads your post tags to your custom post type */
	register_taxonomy_for_object_type('post_tag', 'program');
	
} 

	// adding the function to the Wordpress init
	add_action( 'init', 'custom_program');
	
	/*
	for more information on taxonomies, go here:
	http://codex.wordpress.org/Function_Reference/register_taxonomy
	*/
	
	// now let's add custom categories (these act like categories)
    register_taxonomy( 'program_cat', 
    	array('program'), /* if you change the name of register_post_type( 'custom_type', then you have to change this */
    	array('hierarchical' => true,     /* if this is true it acts like categories */             
    		'labels' => array(
    			'name' => __( 'Program Categories' ), /* name of the custom taxonomy */
    			'singular_name' => __( 'Program Category' ), /* single taxonomy name */
    			'search_items' =>  __( 'Search Program Categories' ), /* search title for taxomony */
    			'all_items' => __( 'All Program Categories' ), /* all title for taxonomies */
    			'parent_item' => __( 'Parent Program Category' ), /* parent title for taxonomy */
    			'parent_item_colon' => __( 'Parent Program Category:' ), /* parent taxonomy title */
    			'edit_item' => __( 'Edit Program Category' ), /* edit custom taxonomy title */
    			'update_item' => __( 'Update Program Category' ), /* update title for taxonomy */
    			'add_new_item' => __( 'Add New Program Category' ), /* add new title for taxonomy */
    			'new_item_name' => __( 'New Program Category Name' ) /* name title for taxonomy */
    		),
    		'show_ui' => true,
    		'query_var' => true,
    	)
    );   
    
	// now let's add custom tags (these act like categories)
    register_taxonomy( 'program_tag', 
    	array('program'), /* if you change the name of register_post_type( 'custom_type', then you have to change this */
    	array('hierarchical' => false,    /* if this is false, it acts like tags */                
    		'labels' => array(
    			'name' => __( 'Program Tags' ), /* name of the custom taxonomy */
    			'singular_name' => __( 'Program Tag' ), /* single taxonomy name */
    			'search_items' =>  __( 'Search Program Tags' ), /* search title for taxomony */
    			'all_items' => __( 'All Program Tags' ), /* all title for taxonomies */
    			'parent_item' => __( 'Parent Program Tag' ), /* parent title for taxonomy */
    			'parent_item_colon' => __( 'Parent Program Tag:' ), /* parent taxonomy title */
    			'edit_item' => __( 'Edit Program Tag' ), /* edit custom taxonomy title */
    			'update_item' => __( 'Update Program Tag' ), /* update title for taxonomy */
    			'add_new_item' => __( 'Add New Program Tag' ), /* add new title for taxonomy */
    			'new_item_name' => __( 'New Program Tag Name' ) /* name title for taxonomy */
    		),
    		'show_ui' => true,
    		'query_var' => true,
    	)
    ); 
	

?>